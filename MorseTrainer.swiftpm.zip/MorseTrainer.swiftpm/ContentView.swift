//Final Listing 5/15/25 (Single File for Playgrounds 4+)
/*
 Drop story.txt into your Playground’s Resources folder.
 Press Start to play the story as clean Morse code at the selected WPM.
 Adjust the slider live to change WPM and re-render playback. Note: in this version, START button must be pressed for speed to change
 
 Possible improvements:
 Character-by-character highlighting during playback
 Live waveform preview
 
 */



import SwiftUI
import AVFoundation
import UIKit

// App Entry
//@main
struct MorsePlaygroundApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

// View Model
@MainActor
class MorseViewModel: ObservableObject {
    @Published var wpm: Double = 15 // Mutable for UI slider
    @Published var isPlaying = false // Mutable for playback state
    @Published var showStory = false // Mutable for story toggle
    @Published var isButtonDisabled = false // Mutable for debouncing
    @Published var errorMessage: String? // Mutable for errors
    
    let player = MorsePlayer() // Immutable; initialized once
    let story: String // Immutable; set in init
    private var playbackTask: Task<Void, Never>? // Mutable for task
    
    init() {
        self.story = loadStory()
        setupErrorObserver()
    }
    
    func togglePlay() {
        guard !isButtonDisabled else { return }
        isButtonDisabled = true
        let haptic = UIImpactFeedbackGenerator(style: .medium)
        haptic.impactOccurred()
        Task {
            if isPlaying {
                await stopPlayback()
            } else {
                await startPlayback()
            }
            await MainActor.run {
                self.isButtonDisabled = false
            }
        }
    }
    
    private func startPlayback() async {
        guard !story.isEmpty else {
            await MainActor.run {
                self.errorMessage = "No valid story to play"
                self.isButtonDisabled = false
            }
            return
        }
        
        await MainActor.run {
            self.isPlaying = true
            self.objectWillChange.send()
        }
        
        let morse = textToMorse(story)
        guard !morse.isEmpty else {
            await MainActor.run {
                self.errorMessage = "Failed to convert story to Morse code"
                self.isPlaying = false
                self.isButtonDisabled = false
                self.objectWillChange.send()
            }
            return
        }
        
        playbackTask = Task {
            await player.play(morse: morse, wpm: wpm)
            await MainActor.run {
                if !Task.isCancelled {
                    self.isPlaying = false
                    self.playbackTask = nil
                    self.objectWillChange.send()
                }
            }
        }
    }
    
    private func stopPlayback() async {
        guard let task = playbackTask else {
            await MainActor.run {
                self.isButtonDisabled = false
            }
            return
        }
        task.cancel()
        await player.stop()
        await MainActor.run {
            self.playbackTask = nil
            self.isPlaying = false
            self.objectWillChange.send()
        }
    }
    
    func updateWPMIfPlaying() {
        if isPlaying {
            Task {
                await stopPlayback()
                await startPlayback()
            }
        }
    }
    
    private func setupErrorObserver() {
        NotificationCenter.default.addObserver(
            forName: .morsePlayerError,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self else { return }
            let error = notification.userInfo?["error"] as? String
            Task { @MainActor in
                if let error {
                    self.errorMessage = error
                }
            }
        }
    }
}

// Main View
struct ContentView: View {
    @StateObject private var viewModel = MorseViewModel()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Morse Code Trainer")
                .font(.title)
                .padding()
            
            Button(action: { viewModel.togglePlay() }) {
                if viewModel.isButtonDisabled {
                    ProgressView()
                        .progressViewStyle(.circular)
                } else {
                    Text(viewModel.isPlaying ? "Stop" : "Start")
                }
            }
            .disabled(viewModel.isButtonDisabled)
            .padding(20)
            .frame(minWidth: 120, minHeight: 60) // iPad touch target
            .background(viewModel.isPlaying ? Color.red : Color.green)
            .foregroundColor(.white)
            .cornerRadius(10)
            .animation(.easeInOut(duration: 0.2), value: viewModel.isPlaying)
            .accessibilityLabel(viewModel.isPlaying ? "Stop Morse code playback" : "Start Morse code playback")
            .accessibilityHint("Toggles Morse code story playback")
            
            Slider(value: $viewModel.wpm, in: 5...30, step: 1) {
                Text("WPM")
            }
            .onChange(of: viewModel.wpm) { oldValue, newValue in
                viewModel.updateWPMIfPlaying()
            }
            
            .accessibilityLabel("Words per minute slider")
            .accessibilityHint("Adjusts Morse code speed from 5 to 30 WPM")
            
            Text("Speed: \(Int(viewModel.wpm)) WPM")
            
            Button("Display Story") {
                viewModel.showStory.toggle()
            }
            .accessibilityLabel("Toggle story display")
            .accessibilityHint("Shows or hides story text")
            
            if viewModel.showStory {
                ScrollView {
                    Text(viewModel.story)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .frame(maxHeight: 200)
                .accessibilityLabel("Story text")
            }
            
            Spacer()
        }
        .padding()
        .alert("Error", isPresented: Binding(
            get: { viewModel.errorMessage != nil },
            set: { _ in viewModel.errorMessage = nil }
        )) {
            Button("OK") { }
        } message: {
            Text(viewModel.errorMessage ?? "Unknown error")
        }
    }
}

// Utility Functions
func loadStory() -> String {
    guard let url = Bundle.main.url(forResource: "story", withExtension: "txt"),
          let text = try? String(contentsOf: url, encoding: .utf8) else {
        return "Default story: Learn Morse code today."
    }
    return text
}

func textToMorse(_ text: String) -> String {
    let morseMap: [Character: String] = [
        "A": ".-", "B": "-...", "C": "-.-.", "D": "-..", "E": ".", "F": "..-.",
        "G": "--.", "H": "....", "I": "..", "J": ".---", "K": "-.-", "L": ".-..",
        "M": "--", "N": "-.", "O": "---", "P": ".--.", "Q": "--.-", "R": ".-.",
        "S": "...", "T": "-", "U": "..-", "V": "...-", "W": ".--", "X": "-..-",
        "Y": "-.--", "Z": "--..", "0": "-----", "1": ".----", "2": "..---",
        "3": "...--", "4": "....-", "5": ".....", "6": "-....", "7": "--...",
        "8": "---..", "9": "----.", ".": ".-.-.-", ",": "--..--", "?": "..--..",
        "!": "-.-.--", " ": " "
    ]
    
    let result = text.uppercased().compactMap { morseMap[$0] }.joined(separator: " ")
    if result.isEmpty {
        print("Warning: Text contains unmapped characters")
    }
    return result
}

// Audio Playback
@MainActor
class MorsePlayer {
    private var engine: AVAudioEngine? // Mutable for reset
    private var player: AVAudioPlayerNode? // Mutable for reset
    private let sampleRate: Double = 44100 // Immutable constant
    private let toneFrequency: Float = 800.0 // Immutable constant
    private var bufferQueue: [AVAudioPCMBuffer] = [] // Mutable for queue
    
    func play(morse: String, wpm: Double) async {
        await stop()
        
        let engine = AVAudioEngine()
        let player = AVAudioPlayerNode()
        self.engine = engine
        self.player = player
        
        let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 1)!
        engine.attach(player)
        engine.connect(player, to: engine.mainMixerNode, format: format)
        
        do {
            try engine.start()
        } catch {
            await MainActor.run {
                NotificationCenter.default.post(name: .morsePlayerError, object: nil, userInfo: ["error": "Audio engine failed: \(error.localizedDescription)"])
            }
            return
        }
        
        player.play()
        
        let dotDuration = 1.2 / wpm
        bufferQueue = morse.flatMap { symbol -> [AVAudioPCMBuffer] in
            switch symbol {
            case ".": return [toneBuffer(duration: dotDuration), silenceBuffer(duration: dotDuration)]
            case "-": return [toneBuffer(duration: dotDuration * 3), silenceBuffer(duration: dotDuration)]
            case " ": return [silenceBuffer(duration: dotDuration * 3)]
            default: return []
            }
        }
        
        await playNext()
    }
    
    private func playNext() async {
        while !bufferQueue.isEmpty && !Task.isCancelled {
            let buffer = bufferQueue.removeFirst()
            guard let player = player else {
                await stop()
                return
            }
            await MainActor.run {
                if !Task.isCancelled {
                    player.scheduleBuffer(buffer, at: nil, completionHandler: nil)
                }
            }
            let bufferDuration = Double(buffer.frameLength) / sampleRate
            try? await Task.sleep(nanoseconds: UInt64(bufferDuration * 1_000_000_000))
        }
        await stop()
    }
    
    func stop() async {
        bufferQueue.removeAll()
        if let player = player, let engine = engine {
            player.stop()
            player.reset()
            if engine.isRunning {
                engine.disconnectNodeOutput(player)
                engine.detach(player)
                engine.stop()
            }
        }
        player = nil
        engine = nil
        await MainActor.run { print("Playback stopped") }
    }
    
    private func toneBuffer(duration: Double) -> AVAudioPCMBuffer {
        let frameCount = AVAudioFrameCount(sampleRate * duration)
        let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 1)!
        let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frameCount)!
        buffer.frameLength = frameCount
        
        let pointer = buffer.floatChannelData![0]
        let thetaIncrement = 2.0 * Float.pi * toneFrequency / Float(sampleRate)
        let fadeSamples = Int(0.005 * sampleRate)
        let totalSamples = Int(frameCount)
        var theta: Float = 0 // Mutable for iteration
        let gain: Float = 0.3
        
        for i in 0..<totalSamples {
            let sample = sinf(theta) * gain
            if i < fadeSamples {
                pointer[i] = sample * Float(i) / Float(fadeSamples)
            } else if i > totalSamples - fadeSamples {
                pointer[i] = sample * Float(totalSamples - i) / Float(fadeSamples)
            } else {
                pointer[i] = sample
            }
            theta += thetaIncrement
        }
        
        return buffer
    }
    
    private func silenceBuffer(duration: Double) -> AVAudioPCMBuffer {
        let frameCount = AVAudioFrameCount(sampleRate * duration)
        let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 1)!
        let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frameCount)!
        buffer.frameLength = frameCount
        memset(buffer.floatChannelData![0], 0, Int(frameCount) * MemoryLayout<Float>.size)
        return buffer
    }
}

// Notification for errors
extension NSNotification.Name {
    static let morsePlayerError = Notification.Name("MorsePlayerError")
}

