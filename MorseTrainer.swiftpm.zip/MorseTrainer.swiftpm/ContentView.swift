import SwiftUI
import AVFoundation

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    
    @State private var storyText = ""
    @State private var showStory = true
    @State private var currentCharIndex: Int? = nil
    @State private var wpm: Double = 15
    @State private var volume: Float = 0.5
    @State private var isPlaying = false
    @State private var didExit = false
    @State private var playTask: Task<Void, Never>? = nil
    
    @State private var engine: AVAudioEngine? = nil
    @State private var player: AVAudioPlayerNode? = nil
    
    private let sampleRate = 44100.0
    private let freq = 800.0 //this looks interesting!
    private var format: AVAudioFormat {
        AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 1)!
    }
    
    private let morseMap: [Character: String] = [
        "A": ".-", "B": "-...", "C": "-.-.", "D": "-..",
        "E": ".", "F": "..-.", "G": "--.", "H": "....",
        "I": "..", "J": ".---", "K": "-.-", "L": ".-..",
        "M": "--", "N": "-.", "O": "---", "P": ".--.",
        "Q": "--.-", "R": ".-.", "S": "...", "T": "-",
        "U": "..-", "V": "...-", "W": ".--", "X": "-..-",
        "Y": "-.--", "Z": "--..",
        "1": ".----", "2": "..---", "3": "...--", "4": "....-",
        "5": ".....", "6": "-....", "7": "--...", "8": "---..",
        "9": "----.", "0": "-----",
        ".": ".-.-.-", ",": "--..--", "?": "..--..", " ": " "
    ]
    
    var body: some View {
        VStack(spacing: 20) {
            if didExit {
                Text("App has been shut down.\nPlease close the app manually.")
                    .multilineTextAlignment(.center)
                    .font(.title2)
                    .padding()
            } else {
                VStack(spacing: 10) {
                    Button {
                        if isPlaying {
                            stopPlayback()
                        } else {
                            playTask = Task {
                                await playMorse()
                            }
                        }
                    } label: {
                        Text(isPlaying ? "Stop" : "Play Morse")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    
                    Button {
                        showStory.toggle()
                    } label: {
                        Text(showStory ? "Hide Story" : "Show Story")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    
                    Button {
                        exitApp()
                    } label: {
                        Text("Exit")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                }
                .padding(.horizontal)
                .padding(.vertical, 20) // ← This line doubles top/bottom 
                
                if showStory {
                    ScrollView {
                        Text(styledStoryText())
                            .font(.system(size: 18, design: .monospaced))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding()
                    }
                    .background(Color(.secondarySystemBackground))
                }
                
                VStack(spacing: 10) {
                    Text("Speed: \(Int(wpm)) WPM")
                    Slider(value: $wpm, in: 5...30)
                    Text("Volume: \(String(format: "%.2f", volume))")
                    Slider(value: $volume, in: 0...1)
                }
                .padding()
            }
        }
        .onChange(of: scenePhase) {
            if scenePhase == .active {
                if !didExit {
                    initializeAudio()
                    Task { await loadRandomStory() }
                }
            } else if scenePhase == .background || scenePhase == .inactive {
                shutdownAudio()
            }
        }
        .task {
            if storyText.isEmpty && !didExit {
                initializeAudio()
                await loadRandomStory()
            }
        }
    }
    
    func styledStoryText() -> AttributedString {
        var result = AttributedString(storyText)
        if let i = currentCharIndex, i < result.characters.count {
            let index = result.index(result.startIndex, offsetByCharacters: i)
            result[index...index].font = .system(size: 18, weight: .bold, design: .monospaced)
        }
        return result
    }
    
    func stopPlayback() {
        playTask?.cancel()
        playTask = nil
        isPlaying = false
        currentCharIndex = nil
    }
    
    func initializeAudio() {
        let newEngine = AVAudioEngine()
        let newPlayer = AVAudioPlayerNode()
        newEngine.attach(newPlayer)
        newEngine.connect(newPlayer, to: newEngine.mainMixerNode, format: format)
        
        do {
            try newEngine.start()
            engine = newEngine
            player = newPlayer
        } catch {
            print("Failed to start engine: \(error)")
        }
    }
    
    func shutdownAudio() {
        stopPlayback()
        player?.stop()
        engine?.stop()
        player = nil
        engine = nil
    }
    
    func exitApp() {
        stopPlayback()
        shutdownAudio()
        storyText = "App has been shut down."
        didExit = true
    }
    
    func playTone(duration: Double) {
        guard engine != nil, let player = player else { return }
        let frames = Int(sampleRate * duration)
        let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(frames))!
        buffer.frameLength = AVAudioFrameCount(frames)
        let data = buffer.floatChannelData![0]
        
        let theta = 2.0 * Double.pi * freq / sampleRate
        let ramp = Int(min(0.003 * sampleRate, Double(frames) / 2.0))
        
        for i in 0..<frames {
            let fade: Float = i < ramp ? Float(i)/Float(ramp) : (i > frames - ramp ? Float(frames - i)/Float(ramp) : 1.0)
            data[i] = sinf(Float(theta) * Float(i)) * volume * fade
        }
        
        let semaphore = DispatchSemaphore(value: 0)
        player.scheduleBuffer(buffer, completionHandler: {
            semaphore.signal()
        })
        if !player.isPlaying {
            player.play()
        }
        semaphore.wait()
    }
    
    func playMorseCharacter(_ c: Character) async {
        let unit = 1.2 / wpm
        guard let code = morseMap[c.uppercased().first ?? " "] else {
            try? await Task.sleep(nanoseconds: UInt64(unit * 3 * 1_000_000_000))
            return
        }
        for symbol in code {
            if Task.isCancelled { return }
            if symbol == "." {
                playTone(duration: unit)
            } else if symbol == "-" {
                playTone(duration: unit * 3)
            }
            try? await Task.sleep(nanoseconds: UInt64(unit * 1_000_000_000))
        }
        try? await Task.sleep(nanoseconds: UInt64(unit * 2 * 1_000_000_000))
    }
    
    func playMorse() async {
        isPlaying = true
        for (index, char) in storyText.enumerated() {
            if Task.isCancelled { break }
            currentCharIndex = index
            await playMorseCharacter(char)
        }
        currentCharIndex = nil
        isPlaying = false
    }
    
    func loadRandomStory() async {
        let files = ["story", "Allentown", "ColdHarbor"]
        guard let name = files.randomElement(),
              let url = Bundle.main.url(forResource: name, withExtension: "txt") else {
            await MainActor.run { storyText = "Missing story file." }
            return
        }
        do {
            let content = try String(contentsOf: url, encoding: .utf8)
            await MainActor.run {
                storyText = content
            }
        } catch {
            await MainActor.run {
                storyText = "Error loading story: \(error.localizedDescription)"
            }
        }
    }
}
