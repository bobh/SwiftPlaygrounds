import SwiftUI

@main
struct MorseTrainer: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
